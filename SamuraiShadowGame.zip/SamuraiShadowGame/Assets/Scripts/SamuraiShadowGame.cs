using UnityEngine;
using System.Collections.Generic;

// SamuraiShadow: juego 2D completo. Colocar este archivo en Assets/Scripts.
// El controlador se crea automaticamente al iniciar la escena Principal.
public class SamuraiShadowGame : MonoBehaviour
{
    enum GameState { Menu, Playing, Respawning, Dead, Win }
    GameState state = GameState.Menu;
    class Enemy
    {
        public GameObject go;
        public SpriteRenderer sr;
        public string kind;
        public float start, phase, hp, cooldown;
        public bool active = true;
        public float attackTimer;
        public bool attackTriggered;
        public int bossPattern;
    }

    readonly List<GameObject> generated = new List<GameObject>();
    readonly List<Enemy> enemies = new List<Enemy>();
    readonly List<GameObject> pickups = new List<GameObject>();
    readonly List<BoxCollider2D> spikeHitboxes = new List<BoxCollider2D>();
    readonly List<Collider2D> oneWayPlatforms = new List<Collider2D>();
    // Ignoramos SOLAMENTE la plataforma desde la que cae el jugador.
    Collider2D ignoredDropPlatform;
    float dropElapsed;
    float dropMovePause;
    GameObject player; Rigidbody2D body; SpriteRenderer playerSprite; Camera cam;
    AudioSource music, fx; AudioClip ambient, bossMusic, jumpSound, hitSound, collectSound, katanaSound, deathSound;
    Sprite[] idle, run, jump, attack, hurt, dead, commanderIdle, commanderAttack, archerIdle, archerShot;
    Sprite[] bg = new Sprite[3]; Sprite white;
    Texture2D guiPixel;
    Sprite[] platforms = new Sprite[3];
    Sprite spikeArt, crystalArt, slashArt, arrowArt, orbArt, warningArt, portalArt;
    BoxCollider2D playerCollider;
    PhysicsMaterial2D noFriction;
    float coyoteTime, jumpBuffer;
    int level = 1, lives = 3, crystals = 0, kills = 0;
    float timer = 100, invuln = 0, attackTimer = 0, attackCooldown = 0, deathTimer = 0;
    float deathAnimationElapsed = 0f;
    bool deathByTimeout = false;
    const float DeathAnimationDuration = .92f;
    const float RespawnDelay = 1.16f;
    bool grounded, facingRight = true; float bossHP = 18;
    GUIStyle titleStyle, buttonStyle, infoStyle, centerStyle, subtitleStyle, smallStyle, hudValueStyle, bossCueStyle;
    string bossCue = ""; float bossCueTimer = 0f;
    const float WIDTH = 62f, FLOOR = -3.5f, MaxBossHP = 22f;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    static void Launch() { if (FindFirstObjectByType<SamuraiShadowGame>() == null) new GameObject("SamuraiShadow_GameManager").AddComponent<SamuraiShadowGame>(); }

    void Awake()
    {
        Application.targetFrameRate = 60;
        var tex = new Texture2D(2, 2); tex.SetPixels(new[] { Color.white, Color.white, Color.white, Color.white }); tex.Apply();
        white = Sprite.Create(tex, new Rect(0, 0, 2, 2), new Vector2(.5f, .5f), 2);
        guiPixel = tex;
        idle = Load("Samurai/Idle"); run = Load("Samurai/Run"); jump = Load("Samurai/Jump"); attack = Load("Samurai/Attack_1"); hurt = Load("Samurai/Hurt"); dead = Load("Samurai/Dead");
        commanderIdle = Load("Samurai_Commander/Idle"); commanderAttack = Load("Samurai_Commander/Attack_1");
        archerIdle = Load("Samurai_Archer/Idle"); archerShot = Load("Samurai_Archer/Shot");
        for (int i = 0; i < 3; i++)
        {
            bg[i] = Resources.Load<Sprite>("Backgrounds/Nivel" + (i + 1));
            platforms[i] = Resources.Load<Sprite>("Environment/Platform" + (i + 1));
        }
        spikeArt = Resources.Load<Sprite>("Environment/SpikeTrap");
        crystalArt = Resources.Load<Sprite>("Environment/Crystal");
        slashArt = Resources.Load<Sprite>("Environment/SlashArc");
        arrowArt = Resources.Load<Sprite>("Environment/Arrow");
        orbArt = Resources.Load<Sprite>("Environment/SpiritOrb");
        warningArt = Resources.Load<Sprite>("Environment/Warning");
        portalArt = Resources.Load<Sprite>("Environment/Portal");
        noFriction = new PhysicsMaterial2D("Deslizamiento sin friccion") { friction = 0f, bounciness = 0f };
        ambient = Resources.Load<AudioClip>("Sounds/Aventura"); bossMusic = Resources.Load<AudioClip>("Sounds/Boss");
        jumpSound = Resources.Load<AudioClip>("Sounds/Salto"); hitSound = Resources.Load<AudioClip>("Sounds/Golpe"); collectSound = Resources.Load<AudioClip>("Sounds/Cristal");
        katanaSound = Resources.Load<AudioClip>("Sounds/Katana"); deathSound = Resources.Load<AudioClip>("Sounds/Muerte");
        var cameraObj = GameObject.Find("Main Camera"); if (cameraObj == null) cameraObj = new GameObject("Main Camera");
        cam = cameraObj.GetComponent<Camera>(); if (cam == null) cam = cameraObj.AddComponent<Camera>();
        cam.orthographic = true; cam.orthographicSize = 5.4f; cam.clearFlags = CameraClearFlags.SolidColor; cam.backgroundColor = new Color(.13f, .15f, .25f);
        cam.transform.position = new Vector3(0, 0, -20); cam.transform.rotation = Quaternion.identity;
        if (cameraObj.GetComponent<AudioListener>() == null) cameraObj.AddComponent<AudioListener>();
        music = gameObject.AddComponent<AudioSource>(); music.loop = true; music.volume = .25f;
        fx = gameObject.AddComponent<AudioSource>(); fx.volume = .65f;
    }

    Sprite[] Load(string path) { var a = Resources.LoadAll<Sprite>("Sprites/" + path); System.Array.Sort(a, (x, y) => string.CompareOrdinal(x.name, y.name)); return a; }

    void SetupGUI()
    {
        titleStyle = new GUIStyle(GUI.skin.label) { fontSize = 40, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter };
        titleStyle.normal.textColor = new Color(1f, .90f, .66f);
        subtitleStyle = new GUIStyle(GUI.skin.label) { fontSize = 17, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter };
        subtitleStyle.normal.textColor = new Color(.90f, .92f, .98f, .92f);
        infoStyle = new GUIStyle(GUI.skin.label) { fontSize = 19, fontStyle = FontStyle.Bold };
        infoStyle.normal.textColor = Color.white;
        hudValueStyle = new GUIStyle(infoStyle) { fontSize = 17 };
        centerStyle = new GUIStyle(infoStyle) { alignment = TextAnchor.MiddleCenter, fontSize = 23, wordWrap = true };
        smallStyle = new GUIStyle(GUI.skin.label) { fontSize = 15, alignment = TextAnchor.MiddleCenter, wordWrap = true };
        smallStyle.normal.textColor = new Color(.82f, .85f, .92f, .95f);
        bossCueStyle = new GUIStyle(GUI.skin.label) { fontSize = 16, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter };
        bossCueStyle.normal.textColor = new Color(1f, .92f, .72f);
        buttonStyle = new GUIStyle(GUI.skin.button) { fontSize = 21, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter };
        buttonStyle.normal.textColor = Color.white;
        buttonStyle.hover.textColor = Color.white;
        buttonStyle.active.textColor = Color.white;
    }

    void DestroyStage()
    {
        RestoreDropCollision();
        foreach (var o in generated) if (o != null) Destroy(o);
        generated.Clear(); enemies.Clear(); pickups.Clear(); spikeHitboxes.Clear(); oneWayPlatforms.Clear();
        player = null; body = null; playerCollider = null;
        dropElapsed = 0f; dropMovePause = 0f;
    }
    GameObject Spawn(string name, Vector3 pos) { var g = new GameObject(name); g.transform.position = pos; generated.Add(g); return g; }

    SpriteRenderer Image(string name, Sprite sprite, Vector3 pos, int order, float scale = 1)
    {
        var g = Spawn(name, pos); var r = g.AddComponent<SpriteRenderer>(); r.sprite = sprite; r.sortingOrder = order; g.transform.localScale = Vector3.one * scale; return r;
    }

    GameObject Block(string name, float x, float y, float w, float h, Color color, bool solid = true, int order = 1)
    {
        var r = Image(name, white, new Vector3(x, y, 0), order); r.color = color; r.transform.localScale = new Vector3(w, h, 1);
        if (solid) { var c = r.gameObject.AddComponent<BoxCollider2D>(); c.size = Vector2.one; }
        return r.gameObject;
    }

    SpriteRenderer FittedSprite(string name, Sprite sprite, Vector3 pos, int order, float width, float height)
    {
        var r = Image(name, sprite != null ? sprite : white, pos, order);
        Vector2 size = r.sprite.bounds.size;
        r.transform.localScale = new Vector3(width / Mathf.Max(.01f, size.x), height / Mathf.Max(.01f, size.y), 1f);
        return r;
    }

    void StartLevel(int next)
    {
        DestroyStage(); level = next; timer = level == 3 ? 150 : level == 2 ? 115 : 105;
        invuln = 1.5f; attackTimer = 0; bossHP = MaxBossHP; deathAnimationElapsed = 0f; deathByTimeout = false; bossCue = ""; bossCueTimer = 0f;
        coyoteTime = 0f; jumpBuffer = 0f;
        if (music != null) { music.Stop(); music.clip = level == 3 ? bossMusic : ambient; if (music.clip != null) music.Play(); }

        BuildScenery();
        BuildPlatformsAndPickups();
        // El nivel final es una arena EXCLUSIVA: no hay guardias, ninjas,
        // arqueros, espiritus ni trampas de pinchos, solo el Shogun.
        if (level != 3) BuildEnemies();

        if (level == 3)
            AddEnemy("Boss", 54, FLOOR + 1.5f);
        else
        {
            FittedSprite("Portal magico animable", portalArt, new Vector3(58, FLOOR + 1.4f, 0), 18, 1.7f, 2.7f);
        }

        player = Spawn("Samurai protagonista", new Vector3(level == 3 ? 43.5f : 1.2f, FLOOR + 1.4f, 0));
        playerSprite = player.AddComponent<SpriteRenderer>(); playerSprite.sortingOrder = 30; playerSprite.sprite = idle.Length > 0 ? idle[0] : white;
        body = player.AddComponent<Rigidbody2D>(); body.gravityScale = 2.95f;
        body.freezeRotation = true; body.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
        body.interpolation = RigidbodyInterpolation2D.Interpolate;
        playerCollider = player.AddComponent<BoxCollider2D>();
        playerCollider.size = new Vector2(.58f, 1.25f);
        playerCollider.offset = new Vector2(0, -.04f);
        playerCollider.sharedMaterial = noFriction;
        cam.transform.position = new Vector3(level == 3 ? 49f : 5f, 0, -20);
    }

    void BuildScenery()
    {
        cam.backgroundColor = level == 1 ? new Color(.24f, .43f, .39f)
            : level == 2 ? new Color(.42f, .31f, .43f) : new Color(.11f, .12f, .23f);

        // Cada mapa tiene un fondo de 2048x768: bosque de bambu, templo y castillo nocturno.
        // Evitamos dibujar grandes rectangulos por delante del paisaje, para no tapar el arte.
        if (bg[level - 1] != null)
        {
            var r = Image("Mapa japones ilustrado", bg[level - 1], new Vector3(29f, -.25f, 10f), -20);
            r.transform.localScale = new Vector3(1.07f, 1f, 1f);
        }

        Color earth = level == 1 ? new Color(.20f, .31f, .24f) :
                      level == 2 ? new Color(.31f, .25f, .30f) : new Color(.16f, .16f, .23f);
        var floor = Block("Suelo solido", 30, FLOOR - .70f, 66, 1.4f, earth, true, 7);
        floor.GetComponent<BoxCollider2D>().sharedMaterial = noFriction;
        Block("Borde del camino", 30, FLOOR - .035f, 66, .09f,
            level == 1 ? new Color(.66f, .73f, .44f) :
            level == 2 ? new Color(.66f, .53f, .46f) : new Color(.49f, .40f, .59f), false, 8);
        for (int i = 0; i < 100; i++)
        {
            float x = .4f + i * .61f;
            float h = .016f + ((i * 17) % 7) * .008f;
            Color c = level == 1 ? new Color(.40f, .53f, .34f, .65f) :
                      level == 2 ? new Color(.68f, .55f, .47f, .65f) : new Color(.46f, .42f, .57f, .65f);
            Block("Detalle suelo", x, FLOOR + h, .10f + (i % 3) * .05f, .025f, c, false, 9);
        }
        // Detalles en primer plano sin bloquear el salto o la colision del jugador.
        for (int i = 0; i < 12; i++)
        {
            float x = 3f + i * 4.7f;
            if (level == 1 && i % 3 == 1) DecorativeShrub(x, FLOOR + .12f, new Color(.31f, .56f, .32f), 10);
            if (level == 2 && i % 3 == 1) DecorativeStoneLantern(x, FLOOR + .78f, 10);
            if (level == 3 && i % 2 == 0) DecorativeTorch(x, FLOOR + 1.04f, 10);
        }
    }

    void BuildPlatformsAndPickups()
    {
        if (level == 3)
        {
            // Arena limpia: cuatro plataformas estrategicas y SIN pinchos ni
            // esbirros; todo el peligro procede del jefe final.
            for (int i = 0; i < 4; i++)
            {
                float x = 45.5f + i * 3.65f;
                float y = -1.84f + (i % 2) * .48f;
                DecorativePlatform(x, y);
            }
            return;
        }
        // El primer piso debe estar al alcance de un unico salto desde el suelo.
        for (int i = 0; i < 17; i++)
        {
            float x = 5f + i * 3.15f;
            float y = -1.95f + (i % 3) * .49f;
            DecorativePlatform(x, y);
            if (i % 2 == 0) Collectible(x, y + .85f);
        }
        for (int i = 0; i < 8; i++) Collectible(3f + i * 6.7f, FLOOR + 1.1f);
        for (int i = 0; i < 9; i++) DecorativeSpikeTrap(10f + i * 5.2f, FLOOR + .12f);
    }

    void DecorativePlatform(float x, float y)
    {
        // Dos objetos separados: apariencia y colision. Esta es una plataforma one-way:
        // el jugador puede saltar atravesandola desde abajo y aterrizar por arriba.
        FittedSprite("Tarima japonesa detallada", platforms[level - 1],
            new Vector3(x, y, 0), 20, 2.42f, .56f);
        var collision = Spawn("Plataforma UN SOLO SENTIDO", new Vector3(x, y + .08f, 0));
        var box = collision.AddComponent<BoxCollider2D>();
        box.size = new Vector2(2.40f, .26f);
        box.sharedMaterial = noFriction;
        var effect = collision.AddComponent<PlatformEffector2D>();
        effect.useOneWay = true;
        effect.surfaceArc = 155f;
        box.usedByEffector = true;
        oneWayPlatforms.Add(box);
    }

    void DecorativeSpikeTrap(float x, float y)
    {
        // Carteles y colores de alto contraste: la trampa se distingue del piso.
        // y = FLOOR + .12f. La ilustracion no tiene collider de dano.
        Block("Borde negro de seguridad", x, FLOOR + .015f, 1.12f, .16f,
            new Color(.12f, .10f, .14f), false, 20);
        Block("Base roja de peligro", x, FLOOR + .09f, 1.09f, .12f,
            new Color(.94f, .19f, .18f), false, 21);
        for (int j = 0; j < 4; j++)
        {
            var stripe = Block("Rayas amarillas de advertencia", x - .39f + j * .25f,
                FLOOR + .038f, .12f, .055f, new Color(1f, .78f, .15f), false, 22);
            stripe.transform.rotation = Quaternion.Euler(0f, 0f, -25f);
        }
        var spikes = FittedSprite("Pinchos blancos con borde rojo", spikeArt,
            new Vector3(x, FLOOR + .31f, 0), 23, 1.00f, .53f);
        spikes.color = new Color(1f, .99f, .98f);
        // Indicador pequeno a un lado, sin interferir con la trayectoria del samurai.
        var signal = FittedSprite("Advertencia de pinchos", warningArt,
            new Vector3(x - .58f, FLOOR + .61f, 0), 24, .30f, .30f);
        signal.color = new Color(1f, .62f, .28f, .92f);

        // La zona peligrosa SOLO se evalua contra los PIES del jugador.
        // El torso y la cabeza pueden pasar cerca sin recibir dano falso.
        var trigger = Spawn("HITBOX PINCHOS - zona de los pies", new Vector3(x, FLOOR + .26f, 0f));
        var box = trigger.AddComponent<BoxCollider2D>();
        box.isTrigger = true;
        box.size = new Vector2(.70f, .62f); // X mas estrecha que el sprite; Y desde el piso hasta las puntas.
        spikeHitboxes.Add(box);
    }

    void CheckSpikeDamage()
    {
        if (playerCollider == null || !playerCollider.enabled || player == null) return;
        Bounds feetBounds = playerCollider.bounds;
        float footY = feetBounds.min.y;
        // Centro de apoyo del samurai, no su cabeza ni los hombros.
        float innerHalfWidth = Mathf.Min(.13f, feetBounds.extents.x * .52f);
        float toeLeft = feetBounds.center.x - innerHalfWidth;
        float toeRight = feetBounds.center.x + innerHalfWidth;

        foreach (var box in spikeHitboxes)
        {
            if (box == null || !box.enabled) continue;
            Bounds hazard = box.bounds;
            bool feetOverSpikes = toeRight > hazard.min.x && toeLeft < hazard.max.x;
            bool footInsideHeight = footY >= hazard.min.y - .05f && footY <= hazard.max.y;
            if (feetOverSpikes && footInsideHeight)
            {
                TakeDamage();
                break;
            }
        }
    }

    void Collectible(float x, float y)
    {
        var r = FittedSprite("Cristal magico", crystalArt, new Vector3(x, y, 0), 24, .54f, .64f);
        pickups.Add(r.gameObject);
    }

    void SetBossCue(string text, float duration = 1.0f)
    {
        bossCue = text;
        bossCueTimer = duration;
    }

    string BossPatternName(int pattern)
    {
        switch (pattern)
        {
            case 0: return "TAJO VELOZ";
            case 1: return "LLUVIA DE FLECHAS";
            case 2: return "ORBE MALDITO";
            default: return "DOBLE CORTE";
        }
    }

    void BuildEnemies()
    {
        for (int i = 0; i < 14; i++)
        {
            float x = 8 + i * 3.65f; string kind = i % 4 == 0 ? "Archer" : i % 4 == 1 ? "Ninja" : i % 4 == 2 ? "Spirit" : "Guard";
            if (level == 1 && kind == "Spirit") kind = "Guard";
            AddEnemy(kind, x, kind == "Spirit" ? -.15f : FLOOR + .95f);
        }
    }

    void AddEnemy(string kind, float x, float y)
    {
        Sprite[] frames = kind == "Archer" ? archerIdle : kind == "Boss" ? commanderIdle : idle;
        var r = Image(kind + " enemigo", frames.Length > 0 ? frames[0] : white, new Vector3(x, y, 0), 29, kind == "Boss" ? 1.9f : kind == "Spirit" ? .9f : 1f);
        if (kind == "Ninja") r.color = new Color(.56f, .64f, .87f);
        if (kind == "Spirit") r.color = new Color(.45f, 1f, .95f, .8f);
        if (kind == "Boss") r.color = new Color(.9f, .55f, .65f);
        enemies.Add(new Enemy { go = r.gameObject, sr = r, kind = kind, start = x, phase = Random.value * 6f, hp = kind == "Boss" ? MaxBossHP : kind == "Ninja" ? 2 : 1, cooldown = Random.Range(.6f, 1.8f) });
    }

    // Solo permite bajar si los pies estan sobre una PLATAFORMA de un sentido.
    // No se aplica al suelo ni a ninguna otra superficie.
    Collider2D PlatformDirectlyUnderFeet()
    {
        if (playerCollider == null || body == null || ignoredDropPlatform != null) return null;
        if (body.linearVelocity.y > .35f) return null;
        Bounds feet = playerCollider.bounds;
        foreach (var platform in oneWayPlatforms)
        {
            if (platform == null || !platform.enabled) continue;
            Bounds surface = platform.bounds;
            bool overlaps = feet.max.x > surface.min.x + .08f && feet.min.x < surface.max.x - .08f;
            bool aligned = Mathf.Abs(feet.min.y - surface.max.y) <= .20f;
            if (overlaps && aligned) return platform;
        }
        return null;
    }

    void BeginDropThrough(Collider2D platform)
    {
        if (platform == null || playerCollider == null || body == null) return;
        ignoredDropPlatform = platform;
        dropElapsed = 0f;
        dropMovePause = .16f;
        Physics2D.IgnoreCollision(playerCollider, ignoredDropPlatform, true);
        coyoteTime = 0f;
        jumpBuffer = 0f;
        grounded = false;
        // Empuje inicial hacia abajo para atravesar la plataforma, sin teletransportes.
        body.linearVelocity = new Vector2(0f, -3.2f);
    }

    void RestoreDropCollision()
    {
        if (playerCollider != null && ignoredDropPlatform != null)
            Physics2D.IgnoreCollision(playerCollider, ignoredDropPlatform, false);
        ignoredDropPlatform = null;
        dropElapsed = 0f;
    }

    void UpdateDropThrough(float dt)
    {
        if (ignoredDropPlatform == null) return;
        dropElapsed += dt;
        if (playerCollider == null || ignoredDropPlatform == null)
        {
            RestoreDropCollision();
            return;
        }
        Bounds playerBounds = playerCollider.bounds;
        Bounds platformBounds = ignoredDropPlatform.bounds;
        // Restaura la colision cuando TODO el personaje ha quedado por debajo
        // de la plataforma, o cuando ya salio del rango horizontal.
        bool completelyBelow = playerBounds.max.y < platformBounds.min.y - .07f;
        bool clearHorizontally = playerBounds.max.x < platformBounds.min.x - .10f ||
                                 playerBounds.min.x > platformBounds.max.x + .10f;
        if ((dropElapsed > .13f && (completelyBelow || clearHorizontally)) || dropElapsed > 1.6f)
            RestoreDropCollision();
    }

    bool IsStandingOnPlatform()
    {
        if (player == null || playerCollider == null || ignoredDropPlatform != null) return false;
        var b = playerCollider.bounds;
        // Los pies quedan fuera del volumen del propio collider.
        Vector2 center = new Vector2(b.center.x, b.min.y - .055f);
        var candidates = Physics2D.OverlapBoxAll(center, new Vector2(.40f, .14f), 0f);
        foreach (var c in candidates)
        {
            if (c == playerCollider || c.isTrigger || !c.enabled || Physics2D.GetIgnoreCollision(playerCollider, c)) continue;
            // El collider detectado debe estar por debajo de los pies.
            if (c.bounds.max.y <= b.min.y + .095f) return true;
        }
        return false;
    }

    void Update()
    {
        if (state != GameState.Playing)
        {
            if (state == GameState.Respawning || state == GameState.Dead)
            {
                deathAnimationElapsed += Time.deltaTime;
                AnimatePlayerDeath();
                if (state == GameState.Respawning && deathAnimationElapsed >= RespawnDelay)
                    FinishRespawn();
                else if (state == GameState.Dead)
                {
                    deathTimer -= Time.deltaTime;
                    if (deathTimer <= 0f)
                    {
                        lives = 3; crystals = 0; kills = 0;
                        StartLevel(1);
                        state = GameState.Playing;
                    }
                }
            }
            return;
        }

        float dt = Time.deltaTime; timer -= dt; invuln -= dt; attackTimer -= dt; attackCooldown -= dt; bossCueTimer -= dt;
        if (timer <= 0) { Die(true); return; }

        // A es la tecla solicitada para bajar por las plataformas. En suelo
        // normal conserva su funcion de caminar a la izquierda.
        // Flecha izquierda sigue moviendo a la izquierda en cualquier momento.
        bool dropKey = Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.S) || Input.GetKeyDown(KeyCode.DownArrow);
        if (dropKey)
        {
            var platform = PlatformDirectlyUnderFeet();
            if (platform != null) BeginDropThrough(platform);
        }
        UpdateDropThrough(dt);
        dropMovePause = Mathf.Max(0f, dropMovePause - dt);

        float horizontal = (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow) ? 1 : 0) - (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow) ? 1 : 0);
        if (dropMovePause > 0f) horizontal = 0f;
        if (horizontal != 0) facingRight = horizontal > 0;
        if (body != null)
        {
            body.linearVelocity = new Vector2(horizontal * 6.2f, body.linearVelocity.y);
            // El raycast anterior podia detectar el collider del propio samurai.
            // Un sensor de pies comprueba SOLO colliders solidos que no son el jugador.
            grounded = IsStandingOnPlatform();
            if (grounded && body.linearVelocity.y <= .25f) coyoteTime = .13f;
            else coyoteTime -= dt;
            if (Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.UpArrow)) jumpBuffer = .13f;
            else jumpBuffer -= dt;
            if (ignoredDropPlatform == null && jumpBuffer > 0f && coyoteTime > 0f)
            {
                // Mas altura: alcanza la primera plataforma en un solo salto.
                body.linearVelocity = new Vector2(body.linearVelocity.x, 13.6f);
                coyoteTime = 0f;
                jumpBuffer = 0f;
                grounded = false;
                Sound(jumpSound);
            }
            if (player.transform.position.y < -7) { LoseLife(); return; }
            float leftLimit = level == 3 ? 42f : .2f;
            float rightLimit = level == 3 ? 59.5f : WIDTH - 1f;
            if (player.transform.position.x < leftLimit) player.transform.position = new Vector3(leftLimit, player.transform.position.y, 0);
            if (player.transform.position.x > rightLimit) player.transform.position = new Vector3(rightLimit, player.transform.position.y, 0);
        }

        if ((Input.GetKeyDown(KeyCode.J) || Input.GetKeyDown(KeyCode.F) || Input.GetKeyDown(KeyCode.LeftControl)) && attackCooldown <= 0)
        {
            attackCooldown = .42f; attackTimer = .26f; Sound(katanaSound);
            SpawnSlash((Vector2)player.transform.position + new Vector2(facingRight ? .9f : -.9f, .15f), facingRight ? 1 : -1, new Color(1f, .93f, .65f, .85f), 1.25f);
            foreach (var e in enemies)
                if (e.active && Mathf.Abs(e.go.transform.position.x - player.transform.position.x) < 2.25f && Mathf.Abs(e.go.transform.position.y - player.transform.position.y) < 1.85f && Mathf.Sign(e.go.transform.position.x - player.transform.position.x) == (facingRight ? 1 : -1))
                    DamageEnemy(e, 1);
        }

        Sprite[] frames = attackTimer > 0 ? attack : !grounded ? jump : Mathf.Abs(horizontal) > .1f ? run : idle;
        if (frames.Length > 0) playerSprite.sprite = frames[(int)(Time.time * (attackTimer > 0 ? 13 : 9)) % frames.Length];
        playerSprite.flipX = !facingRight; playerSprite.color = invuln > 0 && ((int)(Time.time * 9) % 2 == 0) ? new Color(1, 1, 1, .55f) : Color.white;

        for (int i = pickups.Count - 1; i >= 0; i--) if (pickups[i] != null && Vector2.Distance(player.transform.position, pickups[i].transform.position) < .8f)
            { Sound(collectSound); crystals++; Destroy(pickups[i]); pickups.RemoveAt(i); }

        UpdateEnemies(dt);

        // Detecta exclusivamente los pies contra las nueve zonas reales de pinchos.
        CheckSpikeDamage();

        if (level < 3 && player.transform.position.x > 57.5f) { if (level == 1) lives = Mathf.Max(lives, 2); StartLevel(level + 1); return; }
        cam.transform.position = new Vector3(level == 3 ? Mathf.Clamp(player.transform.position.x, 49f, 52f) : Mathf.Clamp(player.transform.position.x, 8f, 53f), Mathf.Clamp(player.transform.position.y * .16f, -.1f, 1.1f), -20);
    }

    void UpdateEnemies(float dt)
    {
        for (int i = 0; i < enemies.Count; i++)
        {
            var e = enemies[i]; if (!e.active) continue; e.phase += dt; e.cooldown -= dt; e.attackTimer -= dt;
            var p = e.go.transform.position;

            // Movement
            if (e.kind == "Spirit")
                p = new Vector3(e.start + Mathf.Sin(e.phase * 2f) * 1.3f, -.2f + Mathf.Cos(e.phase * 2f) * .8f, 0);
            else if (e.kind == "Boss")
            {
                float rage = bossHP <= MaxBossHP * .45f ? 1f : 0f;
                float chaseSpeed = Mathf.Lerp(1.6f, 3.1f, rage);
                float hover = .38f + Mathf.Abs(Mathf.Sin(e.phase * (1.7f + rage * .7f))) * (.38f + rage * .16f);
                p = new Vector3(Mathf.Clamp(p.x + Mathf.Sign(player.transform.position.x - p.x) * dt * chaseSpeed, 47.8f, 57.5f), FLOOR + 1.38f + hover, 0);
            }
            else if (e.attackTimer <= 0 || e.kind == "Ninja")
                p.x = e.start + Mathf.Sin(e.phase * (e.kind == "Ninja" ? 2.4f : 1.3f)) * (e.kind == "Ninja" ? 1.9f : 1.1f);

            e.go.transform.position = p;
            e.sr.flipX = player.transform.position.x < p.x;

            bool attackPose = e.attackTimer > 0;
            Sprite[] sprites = e.kind == "Boss" ? (attackPose ? commanderAttack : commanderIdle) : e.kind == "Archer" ? (attackPose ? archerShot : archerIdle) : (attackPose ? attack : idle);
            if (sprites.Length > 0) e.sr.sprite = sprites[(int)(Time.time * (attackPose ? 10 : 7)) % sprites.Length];

            float dist = Vector2.Distance(player.transform.position, p);

            // Start attacks
            if (e.kind == "Archer")
            {
                if (e.cooldown <= 0 && Mathf.Abs(player.transform.position.x - p.x) < 8.5f) BeginEnemyAttack(e, 0.62f);
                if (e.attackTimer > 0 && !e.attackTriggered && e.attackTimer < 0.26f)
                {
                    e.attackTriggered = true;
                    SpawnArrow(p + new Vector3(.43f * Mathf.Sign(player.transform.position.x - p.x), -.18f, 0f),
                        Mathf.Sign(player.transform.position.x - p.x), new Color(1f, .72f, .18f), 10f, .85f);
                    SpawnSlash((Vector2)p + new Vector2(Mathf.Sign(player.transform.position.x - p.x) * .65f, .25f), Mathf.Sign(player.transform.position.x - p.x), new Color(1f, .68f, .22f, .85f), .55f);
                }
            }
            else if (e.kind == "Spirit")
            {
                if (e.cooldown <= 0 && Mathf.Abs(player.transform.position.x - p.x) < 8f) BeginEnemyAttack(e, 0.58f);
                if (e.attackTimer > 0 && !e.attackTriggered && e.attackTimer < 0.22f)
                {
                    e.attackTriggered = true;
                    SpawnArrow(p + new Vector3(.28f * Mathf.Sign(player.transform.position.x - p.x), -.10f, 0f),
                        Mathf.Sign(player.transform.position.x - p.x), new Color(.38f, 1f, .92f), 7f, .55f);
                    SpawnSlash((Vector2)p, Mathf.Sign(player.transform.position.x - p.x), new Color(.38f, 1f, .92f, .55f), .45f);
                }
            }
            else if (e.kind == "Boss")
            {
                if (e.cooldown <= 0)
                {
                    e.bossPattern = (e.bossPattern + 1) % 4;
                    SetBossCue(BossPatternName(e.bossPattern), 1.05f);
                    BeginEnemyAttack(e, bossHP < MaxBossHP * .45f ? 0.82f : 1.02f);
                }
                if (e.attackTimer > 0 && !e.attackTriggered && e.attackTimer < .42f)
                {
                    e.attackTriggered = true;
                    float dir = Mathf.Sign(player.transform.position.x - p.x);
                    if (e.bossPattern == 0)
                    {
                        e.go.transform.position += Vector3.right * dir * (bossHP < MaxBossHP * .45f ? 1.2f : .9f);
                        p = e.go.transform.position;
                        SpawnSlash((Vector2)p + new Vector2(dir * 1.15f, .26f), dir, new Color(1f, .34f, .42f, .95f), 1.95f);
                        SpawnSlash((Vector2)p + new Vector2(dir * .72f, .05f), dir, new Color(1f, .70f, .78f, .70f), 1.25f);
                        if (Mathf.Abs(player.transform.position.x - p.x) < 2.6f && Mathf.Abs(player.transform.position.y - p.y) < 1.7f) TakeDamage();
                    }
                    else if (e.bossPattern == 1)
                    {
                        for (int k = -1; k <= 1; k++)
                        {
                            SpawnArrow(p + new Vector3(-.85f, k * .22f, 0f), -1f, new Color(1f, .52f, .30f), 8.7f + Mathf.Abs(k), .98f);
                            SpawnArrow(p + new Vector3(.85f, k * .22f, 0f), 1f, new Color(1f, .52f, .30f), 8.7f + Mathf.Abs(k), .98f);
                        }
                        SpawnArrow(p + new Vector3(.60f * dir, .08f, 0f), dir, new Color(1f, .88f, .40f), 11.3f, 1.08f);
                    }
                    else if (e.bossPattern == 2)
                    {
                        SpawnSlash((Vector2)p + new Vector2(0f, .14f), dir, new Color(.95f, .74f, 1f, .90f), 1.35f);
                        SpawnArrow(p + new Vector3(.42f * dir, .08f, 0f), dir, new Color(.70f, .98f, 1f), 9.5f, .95f);
                        SpawnArrow(p + new Vector3(.42f * dir, .34f, 0f), dir, new Color(.88f, .62f, 1f), 10.7f, .84f);
                    }
                    else
                    {
                        SpawnSlash((Vector2)p + new Vector2(-.88f, .10f), -1f, new Color(1f, .52f, .32f, .92f), 1.15f);
                        SpawnSlash((Vector2)p + new Vector2(.88f, .10f), 1f, new Color(1f, .52f, .32f, .92f), 1.15f);
                        if (Mathf.Abs(player.transform.position.x - p.x) < 1.75f && Mathf.Abs(player.transform.position.y - p.y) < 1.4f) TakeDamage();
                    }
                }
            }
            else
            {
                float attackRange = e.kind == "Ninja" ? 1.25f : 1.05f;
                if (e.cooldown <= 0 && dist < attackRange + .25f) BeginEnemyAttack(e, e.kind == "Ninja" ? 0.42f : 0.55f);
                if (e.attackTimer > 0 && !e.attackTriggered && e.attackTimer < (e.kind == "Ninja" ? .16f : .23f))
                {
                    e.attackTriggered = true;
                    float dir = Mathf.Sign(player.transform.position.x - p.x);
                    SpawnSlash((Vector2)p + new Vector2(dir * .65f, .16f), dir, e.kind == "Ninja" ? new Color(.65f, .84f, 1f, .85f) : new Color(1f, .84f, .55f, .82f), e.kind == "Ninja" ? .9f : .75f);
                    if (dist < attackRange && Mathf.Abs(player.transform.position.y - p.y) < 1.15f) TakeDamage();
                    if (e.kind == "Ninja") e.go.transform.position += Vector3.right * dir * .55f;
                }
            }

            if (e.attackTimer <= 0 && e.attackTriggered) e.attackTriggered = false;

            if (Vector2.Distance(player.transform.position, p) < (e.kind == "Boss" ? 1.0f : .58f))
            {
                if (body.linearVelocity.y < -.5f && player.transform.position.y > p.y + .4f && e.kind != "Boss")
                { DamageEnemy(e, 2); body.linearVelocity = new Vector2(body.linearVelocity.x, 8); }
                else if (e.attackTimer <= 0 && e.kind != "Archer" && e.kind != "Spirit") TakeDamage();
            }
        }
    }

    void BeginEnemyAttack(Enemy e, float duration)
    {
        e.attackTimer = duration;
        e.attackTriggered = false;
        e.cooldown = e.kind == "Boss" ? (bossHP < MaxBossHP * .45f ? .88f : 1.28f) : e.kind == "Archer" ? 2.4f : e.kind == "Spirit" ? 2.2f : e.kind == "Ninja" ? 1.1f : 1.5f;
        var warn = FittedSprite("Aviso de ataque", warningArt,
            e.go.transform.position + Vector3.up * (e.kind == "Boss" ? 2.1f : 1.1f),
            36, e.kind == "Boss" ? .92f : .43f, e.kind == "Boss" ? .92f : .43f);
        warn.gameObject.AddComponent<SamuraiFX>().Init(Mathf.Min(duration, .52f), new Vector3(0f, .27f, 0f));
    }

    void SpawnArrow(Vector3 pos, float direction, Color color, float speed, float size)
    {
        bool spirit = color.g > .93f && color.r < .60f;
        Sprite image = spirit ? orbArt : arrowArt;
        float width = spirit ? .78f * size : 1.18f * size;
        float height = spirit ? .78f * size : .48f * size;

        SpriteRenderer r = FittedSprite("Proyectil enemigo visible", image, pos, 33, width, height);
        r.color = spirit ? color : Color.white;
        r.flipX = direction < 0;

        var outline = FittedSprite("Borde proyectil", image, pos, 32, width * 1.26f, height * 1.26f);
        outline.color = spirit ? new Color(1f, 1f, 1f, .42f) : new Color(.06f, .06f, .10f, .95f);
        outline.flipX = direction < 0;
        outline.transform.SetParent(r.transform, true);

        var tint = FittedSprite("Color proyectil", image, pos, 34, width * .88f, height * .88f);
        tint.color = color;
        tint.flipX = direction < 0;
        tint.transform.SetParent(r.transform, true);

        var halo = FittedSprite("Brillo del proyectil", orbArt, pos, 31, width * 1.40f, height * 1.55f);
        halo.color = new Color(color.r, color.g, color.b, spirit ? .33f : .26f);
        halo.transform.SetParent(r.transform, true);

        var trail = FittedSprite("Rastro proyectil", white, pos - Vector3.right * direction * .30f, 30, .38f * size, .10f * size);
        trail.color = new Color(color.r, color.g, color.b, .42f);
        trail.transform.SetParent(r.transform, true);

        r.gameObject.AddComponent<SamuraiArrow>().Init(this, direction, speed, size * .56f);
    }

    void SpawnSlash(Vector2 pos, float direction, Color color, float scale)
    {
        // Arco de katana real, en lugar de la barra rectangular anterior.
        var r = FittedSprite("Arco de katana", slashArt,
            new Vector3(pos.x, pos.y, 0), 35, 1.5f * scale, 1.5f * scale);
        r.color = color;
        r.flipX = direction < 0;
        r.gameObject.AddComponent<SamuraiFX>().Init(.24f, new Vector3(.62f * direction, .15f, 0f));
    }

        public void ArrowHit() { TakeDamage(); }

    void DamageEnemy(Enemy e, int damage)
    {
        e.hp -= damage; Sound(hitSound); e.sr.color = Color.white * .8f;
        if (e.kind == "Boss") bossHP = e.hp;
        if (e.hp <= 0)
        {
            e.active = false;
            SpawnSlash(e.go.transform.position + Vector3.up * .2f, 1f, new Color(1f, .45f, .45f, .9f), e.kind == "Boss" ? 2.2f : 1f);
            Destroy(e.go); kills++;
            if (e.kind == "Boss") { state = GameState.Win; music.Stop(); }
        }
    }

    void TakeDamage()
    {
        if (state != GameState.Playing || invuln > 0f) return;
        SpawnSlash(player.transform.position + Vector3.up * .22f, facingRight ? -1f : 1f,
            new Color(1f, .35f, .38f, .95f), 1f);
        LoseLife();
    }

    void LoseLife()
    {
        if (state != GameState.Playing) return;
        lives--;
        BeginDeathAnimation(lives <= 0, false);
    }

    void Die(bool timeout)
    {
        if (state != GameState.Playing) return;
        BeginDeathAnimation(true, timeout);
    }

    void BeginDeathAnimation(bool finalDeath, bool timeout)
    {
        RestoreDropCollision();
        dropMovePause = 0f;
        deathByTimeout = timeout;
        // Se ejecuta una sola vez al comenzar la animacion, tanto si muere por dano
        // como si se agota el tiempo de la partida.
        Sound(deathSound);
        deathAnimationElapsed = 0f;
        deathTimer = 3.0f;
        state = finalDeath ? GameState.Dead : GameState.Respawning;
        attackTimer = 0f;
        coyoteTime = 0f;
        jumpBuffer = 0f;
        if (body != null)
        {
            body.linearVelocity = Vector2.zero;
            body.simulated = false; // Congela la fisica para mostrar la secuencia completa.
        }
        if (player != null && player.transform.position.y < FLOOR - .65f)
        {
            // Si se cayo al vacio, recupera una posicion visible para mostrar la muerte.
            player.transform.position = new Vector3(Mathf.Clamp(player.transform.position.x, 1.2f, WIDTH - 2f), FLOOR + .84f, 0f);
        }
        AnimatePlayerDeath();
        if (finalDeath && music != null) music.Stop();
    }

    void AnimatePlayerDeath()
    {
        if (playerSprite == null) return;
        playerSprite.color = Color.white;
        playerSprite.flipX = !facingRight;
        if (dead != null && dead.Length > 0)
        {
            int index = Mathf.Min(dead.Length - 1,
                Mathf.FloorToInt(deathAnimationElapsed / DeathAnimationDuration * dead.Length));
            playerSprite.sprite = dead[index];
        }
        else if (hurt != null && hurt.Length > 0)
        {
            playerSprite.sprite = hurt[Mathf.Min(hurt.Length - 1,
                Mathf.FloorToInt(deathAnimationElapsed * 10f))];
        }
    }

    void FinishRespawn()
    {
        if (player == null || body == null) return;
        float x = Mathf.Clamp(player.transform.position.x - 2.4f, level == 3 ? 43.0f : 1.2f, level == 3 ? 58.0f : WIDTH - 3f);
        // Evita reaparecer encima de la misma trampa.
        for (int n = 0; n < 9; n++)
        {
            float spikeX = 10f + n * 5.2f;
            if (Mathf.Abs(x - spikeX) < 1.1f) x = Mathf.Max(1.2f, x - 1.45f);
        }
        player.transform.position = new Vector3(x, FLOOR + 1.45f, 0f);
        body.simulated = true;
        body.linearVelocity = Vector2.zero;
        if (idle != null && idle.Length > 0) playerSprite.sprite = idle[0];
        state = GameState.Playing;
        invuln = 2f;
        deathAnimationElapsed = 0f;
    }

    void Sound(AudioClip clip) { if (clip != null) fx.PlayOneShot(clip); }

    void DecorativeBamboo(float x, float y, int order)
    {
        Block("Tronco bambu", x, y, .20f, 4.4f, new Color(.32f, .58f, .41f, .72f), false, order);
        for (int j = 0; j < 4; j++)
        {
            float yy = y - 1.4f + j * 1f;
            Block("Hoja bambu I", x - .35f, yy, .45f, .08f, new Color(.38f, .67f, .47f, .72f), false, order + 1).transform.rotation = Quaternion.Euler(0, 0, 28);
            Block("Hoja bambu D", x + .35f, yy + .1f, .45f, .08f, new Color(.38f, .67f, .47f, .72f), false, order + 1).transform.rotation = Quaternion.Euler(0, 0, -28);
        }
    }
    void DecorativeLantern(float x, float y, int order)
    {
        Block("Poste farol", x, y - .55f, .08f, .85f, new Color(.30f, .20f, .14f), false, order);
        Block("Farol papel", x, y, .34f, .42f, new Color(1f, .82f, .42f, .92f), false, order + 1);
        Block("Techo farol", x, y + .28f, .42f, .06f, new Color(.38f, .22f, .18f), false, order + 2);
    }
    void DecorativeStoneLantern(float x, float y, int order)
    {
        Block("Base piedra", x, y - .55f, .24f, .85f, new Color(.58f, .60f, .61f), false, order);
        Block("Linterna piedra", x, y, .38f, .26f, new Color(.77f, .79f, .81f), false, order + 1);
        Block("Luz piedra", x, y, .14f, .14f, new Color(1f, .77f, .36f, .6f), false, order + 2);
        Block("Techo piedra", x, y + .21f, .48f, .08f, new Color(.52f, .55f, .58f), false, order + 3);
    }
    void DecorativeTorii(float x, float y, int order, float scale)
    {
        Block("Torii superior", x, y + .5f * scale, 2.35f * scale, .18f * scale, new Color(.73f, .20f, .18f), false, order + 1);
        Block("Torii barra", x, y + .15f * scale, 1.85f * scale, .12f * scale, new Color(.88f, .46f, .37f), false, order);
        Block("Torii poste izq", x - .72f * scale, y - .45f * scale, .16f * scale, 1.35f * scale, new Color(.77f, .25f, .20f), false, order);
        Block("Torii poste der", x + .72f * scale, y - .45f * scale, .16f * scale, 1.35f * scale, new Color(.77f, .25f, .20f), false, order);
    }
    void DecorativeBanner(float x, float y, Color color, int order)
    {
        Block("Poste bandera", x - .15f, y - .55f, .08f, 1.2f, new Color(.33f, .22f, .16f), false, order);
        Block("Tela bandera", x + .22f, y - .1f, .55f, .75f, color, false, order + 1);
        Block("Emblema", x + .22f, y - .1f, .18f, .18f, new Color(1f, .9f, .65f, .8f), false, order + 2);
    }
    void DecorativeTorch(float x, float y, int order)
    {
        Block("Poste antorcha", x, y - .45f, .08f, .75f, new Color(.36f, .22f, .16f), false, order);
        Block("Fuego", x, y, .18f, .34f, new Color(1f, .55f, .20f, .85f), false, order + 2);
        Block("Aura fuego", x, y, .33f, .50f, new Color(1f, .75f, .34f, .25f), false, order + 1);
    }
    void DecorativeShrub(float x, float y, Color c, int order)
    {
        Block("Arbusto", x, y, .55f, .28f, c, false, order);
        Block("Arbusto", x + .18f, y + .05f, .38f, .24f, c * 1.08f, false, order + 1);
        Block("Arbusto", x - .16f, y + .04f, .34f, .22f, c * .95f, false, order + 1);
    }
    void DecorativeCastleRoof(float x, float y, int order)
    {
        Block("Cuerpo castillo", x, y - .42f, 1.4f, .9f, new Color(.44f, .44f, .52f, .55f), false, order);
        Block("Techo castillo", x, y + .1f, 1.9f, .22f, new Color(.27f, .23f, .35f, .80f), false, order + 1);
        Block("Punta izq", x - .85f, y + .18f, .28f, .16f, new Color(.27f, .23f, .35f, .80f), false, order + 2).transform.rotation = Quaternion.Euler(0, 0, 18);
        Block("Punta der", x + .85f, y + .18f, .28f, .16f, new Color(.27f, .23f, .35f, .80f), false, order + 2).transform.rotation = Quaternion.Euler(0, 0, -18);
    }

    void DrawBossHealthBar(float screenWidth)
    {
        float x = screenWidth * .5f - 218f;
        GUI.Box(new Rect(x, 8f, 436f, 77f), "");
        GUI.Label(new Rect(x + 12f, 9f, 415f, 27f), "SHOGUN OSCURO - JEFE FINAL", infoStyle);
        float fraction = Mathf.Clamp01(bossHP / MaxBossHP);
        Color oldTint = GUI.color;
        GUI.color = new Color(.12f, .10f, .16f, 1f);
        GUI.DrawTexture(new Rect(x + 14f, 43f, 408f, 21f), guiPixel);
        GUI.color = fraction > .50f ? new Color(.85f, .22f, .25f) :
                    fraction > .25f ? new Color(1f, .49f, .22f) : new Color(1f, .14f, .14f);
        GUI.DrawTexture(new Rect(x + 17f, 46f, 402f * fraction, 15f), guiPixel);
        GUI.color = oldTint;
        GUI.Label(new Rect(x + 330f, 8f, 95f, 28f), Mathf.CeilToInt(bossHP) + "/" + Mathf.CeilToInt(MaxBossHP), infoStyle);
        if (bossCueTimer > 0f) GUI.Label(new Rect(x, 82f, 436f, 22f), bossCue, bossCueStyle);
    }

    void OnGUI()
    {
        if (titleStyle == null) SetupGUI();
        float w = Screen.width, h = Screen.height;
        if (state == GameState.Menu)
        {
            Color old = GUI.color;
            GUI.color = new Color(.05f, .07f, .14f, .88f);
            GUI.DrawTexture(new Rect(0, 0, w, h), guiPixel);
            GUI.color = new Color(.08f, .10f, .18f, .94f);
            GUI.Box(new Rect(w / 2 - 330, h / 2 - 220, 660, 440), GUIContent.none);
            GUI.color = new Color(.16f, .18f, .28f, .98f);
            GUI.Box(new Rect(w / 2 - 316, h / 2 - 206, 632, 146), GUIContent.none);
            GUI.Box(new Rect(w / 2 - 316, h / 2 - 48, 632, 162), GUIContent.none);
            GUI.Box(new Rect(w / 2 - 316, h / 2 + 126, 632, 78), GUIContent.none);
            GUI.color = old;

            GUI.Label(new Rect(w / 2 - 290, h / 2 - 188, 580, 52), "SAMURAI SHADOW", titleStyle);
            GUI.Label(new Rect(w / 2 - 270, h / 2 - 138, 540, 30), "La maldicion de los tres templos", subtitleStyle);
            GUI.Label(new Rect(w / 2 - 265, h / 2 - 110, 530, 55), "Atraviesa tres escenarios japoneses, sobrevive a los enemigos y derrota al Shogun Oscuro en un duelo final.", smallStyle);

            GUI.Label(new Rect(w / 2 - 282, h / 2 - 24, 564, 26), "CONTROLES", centerStyle);
            GUI.Label(new Rect(w / 2 - 282, h / 2 + 10, 564, 26), "Mover: A / D o flechas laterales   •   Saltar: ESPACIO / W / flecha arriba", smallStyle);
            GUI.Label(new Rect(w / 2 - 282, h / 2 + 36, 564, 26), "Atacar: J / F / Ctrl izquierdo   •   Bajar plataforma: A, S o flecha abajo", smallStyle);
            GUI.Label(new Rect(w / 2 - 282, h / 2 + 70, 564, 26), "Consejo: observa las advertencias del jefe y esquiva antes de contraatacar.", smallStyle);

            if (GUI.Button(new Rect(w / 2 - 150, h / 2 + 142, 300, 46), "INICIAR AVENTURA", buttonStyle))
            { lives = 3; crystals = 0; kills = 0; StartLevel(1); state = GameState.Playing; }

            return;
        }
        if (state == GameState.Playing || state == GameState.Respawning)
        {
            GUI.Box(new Rect(12, 12, 420, 66), ""); GUI.Label(new Rect(23, 19, 390, 55), "NIVEL " + level + "  |  VIDAS: " + lives + "  |  CRISTALES: " + crystals + "  |  " + Mathf.CeilToInt(timer) + "s", infoStyle);
            GUI.Label(new Rect(w - 310, 12, 300, 38), "Jeffrey Fernandez | 1-21-1476", infoStyle);
            if (level == 3) DrawBossHealthBar(w);
            if (state == GameState.Respawning && deathAnimationElapsed > .68f)
                GUI.Label(new Rect(w / 2 - 190, h * .22f, 380, 54), "VIDA PERDIDA - REAPARECIENDO", centerStyle);
            return;
        }
        // La pantalla final aparece DESPUES de mostrar la animacion de muerte.
        if (state == GameState.Dead && deathAnimationElapsed < DeathAnimationDuration) return;
        GUI.Box(new Rect(w / 2 - 280, h / 2 - 145, 560, 290), "");
        GUI.Label(new Rect(w / 2 - 265, h / 2 - 105, 530, 65), state == GameState.Win ? "¡VICTORIA!" : "HAS MUERTO", titleStyle);
        GUI.Label(new Rect(w / 2 - 260, h / 2 - 30, 520, 50), state == GameState.Win ? "Has derrotado al Shogun Oscuro" : deathByTimeout ? "Se acabo el tiempo. Regresando al nivel 1..." : "Regresando al primer nivel...", centerStyle);
        if (state == GameState.Win)
        {
            if (GUI.Button(new Rect(w / 2 - 250, h / 2 + 55, 235, 55), "VOLVER A JUGAR", buttonStyle)) { lives = 3; crystals = 0; kills = 0; StartLevel(1); state = GameState.Playing; }
            if (GUI.Button(new Rect(w / 2 + 15, h / 2 + 55, 235, 55), "MENU PRINCIPAL", buttonStyle)) { DestroyStage(); state = GameState.Menu; }
        }
    }
}

public class SamuraiArrow : MonoBehaviour
{
    SamuraiShadowGame game; float direction; float life = 4f; float speed = 8f; float radius = .5f;
    public void Init(SamuraiShadowGame owner, float dir, float speedValue, float hitRadius) { game = owner; direction = dir; speed = speedValue; radius = hitRadius; }
    void Update()
    {
        transform.position += Vector3.right * direction * speed * Time.deltaTime;
        life -= Time.deltaTime;
        if (life <= 0) Destroy(gameObject);
        var p = GameObject.Find("Samurai protagonista");
        if (p != null && Vector2.Distance(p.transform.position, transform.position) < radius) { if (game != null) game.ArrowHit(); Destroy(gameObject); }
    }
}

public class SamuraiFX : MonoBehaviour
{
    float life; Vector3 move; SpriteRenderer sr;
    public void Init(float t, Vector3 motion) { life = t; move = motion; sr = GetComponent<SpriteRenderer>(); }
    void Update()
    {
        transform.position += move * Time.deltaTime;
        life -= Time.deltaTime;
        if (sr != null) sr.color = new Color(sr.color.r, sr.color.g, sr.color.b, Mathf.Clamp01(life * 4f));
        transform.localScale *= 1f + Time.deltaTime * 1.7f;
        if (life <= 0) Destroy(gameObject);
    }
}
